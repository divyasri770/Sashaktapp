
import './Home.css';

const Home = () => {
  return (
    <div className="home" >
          
          <p>
            HELLO YOU ARE MOST WELCOME ,EXPLORE OUR CONTENT!!
          </p>
          
        </div>
  );
};

export default Home;
